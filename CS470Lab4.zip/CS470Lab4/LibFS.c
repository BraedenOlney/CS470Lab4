#include "LibFS.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define E_CREATE_ERROR 1
#define E_TOO_MANY_OPEN_FILES 2
#define E_INVALID_FD 3
#define E_OPEN_ERROR 4
#define E_READ_ERROR 5
#define E_WRITE_ERROR 6
#define E_DELETE_ERROR 7
#define E_SEEK_ERROR 8
// Define global variable for error reporting
int osErrno;

// Structure to represent an open file
typedef struct {
    char filename[100]; // File name
    FILE *file;         // File pointer
    int isOpen;         // Flag to check if file is open
} FileDescriptor;

// Array of file descriptors to represent open files
#define MAX_FILES 100
FileDescriptor fileDescriptors[MAX_FILES];

// Initialize fileDescriptors array
void initializeFileDescriptors() {
    for(int i = 0; i<MAX_FILES; i++){
        fileDescriptors[i].isOpen = 0;
        fileDescriptors[i].file = NULL;
    }

}

// Function to create a new file
int fileCreate(const char* filename) {
   FILE *file = fopen(filename, "w");
   if(file==NULL){
    osErrno= E_CREATE_ERROR;
    return -1;
   }

   fclose(file);
   return 0;
}

// Function to open an existing file
int fileOpen(const char* filename) {
    for(int i=0;i<MAX_FILES; i++){
        if(!fileDescriptors[i].isOpen){
            FILE *file = fopen(filename,"r+");
            if(file==NULL){
                osErrno = E_OPEN_ERROR;
                return -1;
            }
            strcpy(fileDescriptors[i].filename,filename);
            fileDescriptors[i].file = file;
            fileDescriptors[i].isOpen = 1;
            return i;
        }
    }
    osErrno = E_OPEN_ERROR;
    return -1;

}

// Function to read data from a file
int fileRead(int fd, void* buffer, int size) {
    if(fd<0 || fd>= MAX_FILES || !fileDescriptors[fd].isOpen){
        osErrno = E_INVALID_FD;
        return -1;
    }
    return fread(buffer,1,size,fileDescriptors[fd].file);
}

// Function to write data to a file
int fileWrite(int fd, const void* buffer, int size) {
    if(fd<0 || fd>= MAX_FILES || !fileDescriptors[fd].isOpen){
        osErrno = E_INVALID_FD;
        return -1;

    }   
    return fwrite(buffer,1,size,fileDescriptors[fd].file);
}


// Function to close an open file
int fileClose(int fd) {
    if(fd<0 || fd>= MAX_FILES || !fileDescriptors[fd].isOpen){
        osErrno = E_INVALID_FD;
        return -1;

    }   
    return fclose(fileDescriptors[fd].file);
    fileDescriptors[fd].isOpen=0;
    return 0;
}

// Function to delete a file
int fileDelete(const char* filename) {
    if(remove(filename)!=0){
        osErrno = E_DELETE_ERROR;
        return -1;
    }
    return 0;
}


#ifndef LIBFS_H
#define LIBFS_H

// Error codes
extern int osErrno;

// File operations
void initializeFileDescriptors();
int fileCreate(const char* file);
int fileOpen(const char* file);
int fileRead(int fd, void* buffer, int size);
int fileWrite(int fd, const void* buffer, int size);
int fileClose(int fd);
int fileDelete(const char* file);

#endif // LIBFS_H

#include "LibFS.h"
#include <stdio.h>
#include <string.h>

int main() {
    const char* testFileName = "BraedenOlney_Introduction.txt";
    char buffer[100000];
    const char* writeData = "Hello CS470. This project shows the development of User-Lever file system libary. made with a C program.\n In this Program the fill will be created, opened, read, wrote, closed, and deleted. Watch and see!";
    int bytesRead;

    //initialize file Descriptors
    initializeFileDescriptors();

    //testFileList = ["test1.txt","test2.txt","test3.txt"]
    const char* fileList[] = {"test1.txt","test2.txt","test3.txt"};
    int n = sizeof(fileList)/sizeof(fileList[0]);
    int fds[n];

    //open files from file list
    // for(int i=0;i<n;i++){
    //     printf("Creating and opening file: %s\n",fileList[i]);
    //     if(fileCreate(fileList[i])!=0 || fileOpen(fileList[i])<0){
    //         printf("Failed to open and create");
    //         continue;
    //     }

    //     printf("File open successfully file: %s, FD: %d\n", fileList[i],fds[i]);

    // }

    // for(int i = 0;i<n; i++){
    //     if(fds[i]<0) continue;
    //     printf("Writing to file: %d\n",fds[i]);for(int i=0;i<n;i++for(int i=0;i<n;i++){
    //     printf("Creating and opening file: %s\n",fileList[i]);for(int i=0;i<n;i++){
    //     printf("Creating and opening file: %s\n",fileList[i]);
    //     if(fileCreate(fileList[i])!=0 || fileOpen(fileList[i])<0){
    //         printf("Failed to open and create");
    //         continue;
    //     }

    //     printf("File open successfully file: %s, FD: %d\n", fileList[i],fds[i]);

    // }

    // for(int i = 0;i<n; i++){
    //     if(fds[i]<0) continue;
    //     printf("Writing to file: %d\n",fds[i]);

    //     if (fileWrite(fds[i], writeData,strlen(writeData))> 0){
    //         printf("Data written successfully \n");
    //     }else{
    //         printf("Failed to write data to file. \n");
    //     }

    // }
    //     if(fileCreate(fileList[i])!=0 || fileOpen(fileList[i])<0){
    //         printf("Failed to open and create");
    //         continue;
    //     }

    //     printf("File open successfully file: %s, FD: %d\n", fileList[i],fds[i]);

    // }

    // for(int i = 0;i<n; i++){
    //     if(fds[i]<0) continue;
    //     printf("Writing to file: %d\n",fds[i]);

    //     if (fileWrite(fds[i], writeData,strlen(writeData))> 0){
    //         printf("Data written successfully \n");
    //     }else{
    //         printf("Failed to write data to file. \n");
    //     }

    // }nt i=0;i<n;i++){
    //     printf("Creating and opening file: %s\n",fileList[i]);
    //     if(fileCreate(fileList[i])!=0 || fileOpen(fileList[i])<0){
    //         printf("Failed to open and create");
    //         continue;
    //     }

    //     printf("File open successfully file: %s, FD: %d\n", fileList[i],fds[i]);

    // }

    // for(int i = 0;i<n; i++){
    //     if(fds[i]<0) continue;
    //     printf("Writing to file: %d\n",fds[i]);

    //     if (fileWrite(fds[i], writeData,strlen(writeData))> 0){
    //         printf("Data written successfully \n");
    //     }else{
    //         printf("Failed to write data to file. \n");
    //     }

    // }
    //     if(fileCreate(fileList[i])!=0 || fileOpen(fileList[i])<0){
    //         printf("Failed to open and create");
    //         continue;
    //     }

    //     printf("File open successfully file: %s, FD: %d\n", fileList[i],fds[i]);

    // }

    // for(int i = 0;i<n; i++){
    //     if(fds[i]<0) continue;
    //     printf("Writing to file: %d\n",fds[i]);

    //     if (fileWrite(fds[i], writeData,strlen(writeData))> 0){
    //         printf("Data written successfully \n");
    //     }else{
    //         printf("Failed to write data to file. \n");
    //     }

    // }
    //         printf("Failed to write data to file. \n");
    //     }

    // }



    // Create a new file
    if (fileCreate(testFileName) == 0) {
        printf("File created successfully.\n");
    } else {
        printf("Failed to create file.\n");
        return 1;
    }

    // Open the file for writing
    int fd = fileOpen(testFileName);
    if(fd>=0){
        printf("File opened successfully for writing. \n");
    }else{
        printf("Failed to open file for writing.\n");
        return 1;
    }

    // Write data to the file
    if (fileWrite(fd, writeData,strlen(writeData))> 0){
        printf("Data written successfully \n");
    }else{
        printf("Failed to write data to file. \n");
    }

    // Close the file
     if (fileClose(fd)==0){
        printf("Data closed successfully after write\n");
    }else{
        printf("Failed to Close the file after writing.\n");
    }

    // Reopen the file for reading
    fd = fileOpen(testFileName);
    if (fd>=0){
        printf("File re-opened successfully for reading.\n");
    }else{
        printf("Failed to open file to read.\n");
        return -1;
    }

    // Read data from the file
    bytesRead = fileRead(fd,buffer,sizeof(buffer)-1);
    if (bytesRead>0){
        buffer[bytesRead]="\0";//Null-terminate the string
        printf("Data read from file %s\n",buffer);
    }else{
        printf("Failed to read data from file.\n");
    }

    // Close the file
    if(fileClose(fd)==0){
        printf("File closed after writing.\n");
    }else{
        printf("Failed tp close file after writing");
    }
     
    // Delete the file
    if(fileDelete(testFileName)>=0){
        printf("File successfully deleted \n");
    }else{
        printf("Failed to Delete file \n");
    } 

    return 0;
}
